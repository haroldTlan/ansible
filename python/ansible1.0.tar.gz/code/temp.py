#!/usr/bin/env python

import time
from o import *

def main(sleep_sec=10):
    while True:
        items = run_playbook("yml/b.yml")
        print items
        time.sleep(sleep_sec)


if __name__ == '__main__':
    main()
