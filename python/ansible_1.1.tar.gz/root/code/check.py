import sys
import argparse
import commands
sys.path.append('/root/check')
from testport import checkport
from mongocheck import *
from mysqlcheck import *
from gatewaycheck import *
from fileservercheck import *
import clouddb
from o import *
#from webcheck import *

parser = argparse.ArgumentParser(description="use bary's check module")
parser.add_argument("--ip", help="default: --ip=192.168.2.149", default='192.168.2.149')
parser.add_argument("--checktype", help="default: --checktype=mysql", default='mysql')

aim = "~/code/yml/vars/server.yml"

def set_database(types, status):
    clouddb.db.connect()
    try:
        cloud = clouddb.Cloud.get(clouddb.Cloud.Settingtype == types)
        if status:
            cloud.Status = True
        else:
            cloud.Status = False
        cloud.save()
        clouddb.db.close()  
 
    except Exception as e:
        #raise 'cannot find this type'
        pass
   
def checkmodule(ip="192.168.2.149", checktype="mysql"):

    if checktype == "mysql":
        if checkmysql(ip) :
            results = "failed:%d"%checkmysql(ip)
        else:
            results = "True"

    elif checktype == "mongo":
        if checkmongo(ip) :
            results = "failed:%d"%checkmongo(ip)
        else:
            results = "True"


    elif checktype == "gateway":
        result =  commands.getoutput("python /root/check/gatewaycheck.py --ip=%s"%ip)
        if not int(result):
            results = "True"
        else:
            results = "failed:%s"%result
    

    elif checktype == "fileserver":
        if checkport(9002, ip=args.ip):
            results = "True"
        else:
            results = "failed:1"
        
    elif checktype == "web":
        if checkport(8081, ip=args.ip):
            results = "True"
        else:
            results = "failed:1"

    elif checktype == "node":
        os.system("sed -i 's/master:.*/master: %s/g' %s"% (ip, aim))
        items = run_playbook("yml/check/node.yml")
        if items.host_ok:
            for i in items.host_ok:
                if i['task'] == 'check node':
                    results = i['result']._result['stdout_lines'][0]
        else:
            results =  items.host_failed.values()[0]._result['stderr']

    else:
        results = "No such type"


    if results == "True":
        set_database(checktype, True)
    else:
        set_database(checktype, False)
    return results
    
if __name__ == '__main__':
    args = parser.parse_args()
    print checkmodule(args.ip, args.checktype)
