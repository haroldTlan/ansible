# -*- coding: utf-8 -*-
import json
from ansible.parsing.dataloader import DataLoader
from ansible.vars import VariableManager
from ansible.inventory import Inventory
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.executor.playbook_executor import PlaybookExecutor

from ansible.plugins import callback_loader

loader = DataLoader()
variable_manager = VariableManager()
inventory = Inventory(loader=loader, variable_manager=variable_manager)
variable_manager.set_inventory(inventory)

class Options(object):
    def __init__(self):
        self.connection = "smart"
        self.forks = 10
        self.check = False
    def __getattr__(self, name):
        return None

options = Options()
def run_adhoc():
    results_callback = callback_loader.get('json')
    variable_manager.extra_vars={"ansible_ssh_user":"root" , "ansible_ssh_pass":"passwd"}
    play_source = {"name":"Ansible Ad-Hoc","hosts":"temp","gather_facts":"no","tasks":[{"action":{"module":"command","args":"python ~/temp"}}]}
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None

    try:
        tqm = TaskQueueManager(
            inventory=inventory,
            variable_manager=variable_manager,
            loader=loader,
            options=options,
            passwords=None,
            #stdout_callback='minimal',
            stdout_callback=results_callback,
            run_tree=False,
        )
        result = tqm.run(play)
        print result
        import pdb
        pdb.set_trace()
        print(results_callback.results)
        #print(results_callback.results[0]['tasks'][0]['hosts']['localhost']['stdout']) 
        dev=results_callback.results[0]['tasks'][0]['hosts']['192.168.2.76']['stdout'] 

        print dev
    finally:
        if tqm is not None:
            tqm.cleanup()

def run_playbook():
    pass




if __name__ == '__main__':
    run_adhoc()

