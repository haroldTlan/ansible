# coding:utf-8
# !/usr/bin/env python
from __future__ import unicode_literals
from peewee import *
import threading

__author__ = 'sam'

db = MySQLDatabase('speediodb', autocommit=True, user='root',
                   passwd='passwd', threadlocals=True, connect_timeout=30)

_local = threading.local()


def local():
    if not hasattr(_local, 'connect_nr'):
        _local.connect_nr = 0
        _local.transaction_nr = 0
        _local.transaction_end = ''
    return _local


inited = False


def begin():
    if local().transaction_nr == 0:
        local().transaction_end = ''
        db.set_autocommit(False)
        db.begin()
    local().transaction_nr += 1


def commit():
    local().transaction_nr -= 1
    if local().transaction_nr == 0:
        db.set_autocommit(True)
        if local().transaction_end == 'rollback':
            db.rollback()
        else:
            db.commit()
    elif local().transaction_nr < 0:
        db.set_autocommit(True)
        raise False


def rollback():
    local().transaction_end = 'rollback'
    local().transaction_nr -= 1
    if local().transaction_nr == 0:
        db.set_autocommit(True)
        db.rollback()
    elif local().transaction_nr < 0:
        db.set_autocommit(True)
        raise False


def connect():
    if local().connect_nr == 0:
        db.connect()
    local().connect_nr += 1


def close():
    local().connect_nr -= 1
    if local().connect_nr == 0:
        db.close()
    elif local().connect_nr < 0:
        raise False


class transaction(object):
    def __enter__(self):
        connect()
        begin()

    def __exit__(self, type, value, traceback):
        if not traceback:
            commit()
        else:
            rollback()
        close()


def with_transaction(func):
    def _with_transaction(*vargs, **kv):
        try:
            connect()
            begin()
            ret = func(*vargs, **kv)
        except Exception as e:
            rollback()
            raise e
        else:
            commit()
        finally:
            close()
        return ret

    return _with_transaction


def with_db(func):
    def _with_db(*vargs, **kv):
        connect()
        try:
            s = func(*vargs, **kv)
        except Exception as e:
            raise e
        finally:
            close()
        return s

    return _with_db

class Cloud(Model):
    uid = IntegerField(primary_key=True)
    Settingtype = CharField()
    Ip = CharField()
    Status = BooleanField()
    
    @classmethod
    def exists(cls, expr):
        return cls.select().where(expr).exists()

    class Meta:
        db_table = 'setting'
        database = db

if not Cloud.table_exists():
    Cloud.create_table()
    
if __name__ == '__main__':
    db.connect()
    db.create_tables([Cloud])
    db.close()
    pass
