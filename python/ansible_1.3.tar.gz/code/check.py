import sys
import argparse
import commands
sys.path.append('/root/check')
from testport import checkport
from mongocheck import *
from mysqlcheck import *
from gatewaycheck import *
from fileservercheck import *
import clouddb
from o import *
#from webcheck import *

parser = argparse.ArgumentParser(description="use bary's check module")
parser.add_argument("--ip", help="default: --ip=192.168.2.149", default='192.168.2.149')
parser.add_argument("--checktype", help="default: --checktype=mysql", default='mysql')

aim = "~/code/yml/vars/server.yml"

def set_database(types, ip, status):
    clouddb.db.connect()
    try:
        cloud = clouddb.Cloud.get(clouddb.Cloud.Settingtype == types,clouddb.Cloud.Ip == ip)
        if status:
            cloud.Status = True
        else:
            cloud.Status = False
        cloud.save()
        clouddb.db.close()  
 
    except Exception as e:
        #raise 'cannot find this type'
        pass
   
def checkmodule(ip="192.168.2.149", checktype="mysql"):

    if checktype == "mysql":
        if checkmysql(ip) == "success" :
            results = "?True?%s"%checkmysql(ip)
        else:
            results = "?False?%s"%checkmysql(ip)

    elif checktype == "mongo":
        if checkmongo(ip) == "success":
            results = "?True?%s"%checkmongo(ip)
        else:
            results = "?False?%s"%checkmongo(ip)


    elif checktype == "gateway":
        result =  commands.getoutput("python /root/check/gatewaycheck.py --ip=%s"%ip)
        if result == "success":
            results = "?True?%s"%result
        else:
            results = "?False?%s"%result
    

    elif checktype == "fileserver":
        if checkport(9002, ip=args.ip):
            results = "?True?success"
        else:
            results = "?False?port not open"
        
    elif checktype == "web":
        if checkport(8081, ip=args.ip):
            results = "?True?success"
        else:
            results = "?False?port not open"

    elif checktype == "node":
        os.system("sed -i 's/master:.*/master: %s/g' %s"% (ip, aim))
        items = run_playbook("yml/check/node.yml")
        if items.host_ok:
            for i in items.host_ok:
                if i['task'] == 'checknode':
                    result = i['result']._result['stdout_lines'][0]
            
            if result != "None":
                results = "?True?" + result
            else:
                results = "?False?" + result
        else:
            results = "?False?port not open"

    else:
        results = "?False?No such type"


    if results == "?True?success":
        set_database(checktype, ip, True)
    else:
        set_database(checktype, ip, False)
    return results
    
if __name__ == '__main__':
    args = parser.parse_args()
    print checkmodule(args.ip, args.checktype)
